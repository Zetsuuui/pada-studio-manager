# PADA Studio Manager (starter v1)

Next.js 15 + Supabase attendance and fees app. This is a functional starter, **not yet production audited**.

## Setup
1. Install Node.js 20+.
2. Create a Supabase project. In SQL Editor run `supabase/schema.sql`.
3. In Supabase Authentication > Users, create an admin user (email/password). Copy their UUID.
4. In SQL Editor run (replace UUID):
   `insert into public.staff(user_id,name,role) values ('YOUR_AUTH_USER_UUID','PADA Admin','admin');`
5. Copy `.env.example` to `.env.local` and fill in the Supabase project URL and publishable/anon key from Supabase Project Settings. **Never use a service role key in NEXT_PUBLIC variables.**
6. Run `npm install` then `npm run dev`, open http://localhost:3000 and sign in.
7. Open Packages and enter your actual prices (the default fees are zero). Register a student, create enrollment, mark attendance and record payment.

## Important rules
- Monthly expiry is one day before the same calendar date next month; for starts on the 29th–31st, the next month is clamped to its last day. The database validates attendance dates and prevents spending more sessions than allocated, including concurrent inserts.
- Attendance records represent **present only**. Absences are not recorded in this starter. Makeup classes count as ordinary attendance against remaining sessions.
- One present attendance per enrollment per calendar date. If you run multiple sessions per day, add a class_sessions table and change the uniqueness rule.
- Enrollments are independent; renewal creates another enrollment. The app does not currently prevent overlapping active enrollments for the same student.
- Payments are positive cash receipts; refunds have a separate database table, but the UI for issuing refunds is not included. Payments should not be deleted casually. There is no transaction receipt number or overpayment guard yet.
- Teachers can see students, packages, enrollments and attendance but not payments. Admins manage finances and enrollments. The initial admin is bootstrapped manually via SQL.
- Use private Supabase Auth accounts; RLS is enabled. Configure backup/retention, MFA, audit logs, stronger validation and a secure deployment before entering real student or financial records.
- The dashboard uses browser-local date; verify your device is set to Bhutan time. Reports calculate from payment and refund dates.

## What to build next
Attendance absence/cancellation records, class schedules, fee receipts, refund UI, editing student profiles, overpayment prevention, audit logs, CSV export, notifications, and role-based teacher assignment.
