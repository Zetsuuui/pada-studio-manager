import './style.css';
export const metadata={title:'PADA Studio Manager',description:'Attendance and fees for PADA Art Studio'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
